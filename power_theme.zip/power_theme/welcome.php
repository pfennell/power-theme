<img class="admin_theme_screenshot" style="align: right;" src="../wp-content/themes/power_theme/thumb.png" width="300" height="225" alt="Thumb">
<h3>Welcome to The Power Theme!</h3>
<p>Built for the Pro Web Software From PageLines</p>
<p>This framework now has tons of customization options and editing features.
Below is a list of plugins supported by this theme ...
