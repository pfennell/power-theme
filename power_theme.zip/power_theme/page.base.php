<?php
/*
	Template Name: Custom Page
*/

setup_pagelines_template();
