<?php
/*
	Template Name: Home Page
*/

setup_pagelines_template();
