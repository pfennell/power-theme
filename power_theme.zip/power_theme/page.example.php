<?php
/*
	Template Name: Example Page
*/

setup_pagelines_template();
