<?php
/*
	Template Name: About Us Page
*/

setup_pagelines_template();
